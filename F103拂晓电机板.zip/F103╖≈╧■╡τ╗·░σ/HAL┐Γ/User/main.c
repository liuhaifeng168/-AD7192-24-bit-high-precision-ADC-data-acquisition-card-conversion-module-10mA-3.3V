/**
  ******************************************************************************
  * @file    main.c
  * @author  fire
  * @version V1.0
  * @date    2024-xx-xx
  * @brief   
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ�� STM32 F103-����  ����� 
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :https://fire-stm32.taobao.com
  *
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx.h"
#include "./usart/bsp_debug_usart.h"
#include "./led/bsp_led.h"  
#include "./key/bsp_key.h"  
#include "./ad7192/bsp_ad7192.h"
#include "./ad7192_test/ad7192_test.h"

static void SystemClock_Config(void);

/**
  * @brief  ������
  * @param  ��
  * @retval ��
  */
int main(void)
{
  /* ϵͳʱ�ӳ�ʼ����72MHz */
  SystemClock_Config();
  
  /* HAL ���ʼ�� */
  HAL_Init();
	/* �������üĴ���ʱ�� */
	__HAL_RCC_SYSCFG_CLK_ENABLE();
  /* LED �˿ڳ�ʼ�� */
  LED_GPIO_Config();

  /* ���ô���1Ϊ��115200 8-N-1 */
  DEBUG_USART_Config();
  
  /* ������ʼ�� */
  Key_GPIO_Config();
  
  /* AD7192��ʼ�� */
  AD7192_Init();
  
  /* ������λ AD7192 */
  AD7192SoftwareReset();
  
  HAL_Delay(10);
  ReadFromAD7192ViaSPI(REG_ID, 1, AD7192Registers, REG_ID);
  
  if ((AD7192Registers[REG_ID] & 0x0F) != 0)
  {
    printf("AD7192 ��ʼ��ʧ���������ӣ�\r\n");
    while(1);
  }
  printf("AD7192_ID = 0x%X\r\n", AD7192Registers[REG_ID]);
  
//��ad7192_test.h�л�MODE�궨����ѡ��ģʽ
#if MODE == SINGLE_CONVERSION
      /* 4·α���ͨ�����ζ�ʵ�� */
      single_conversion_voltage();
#elif MODE == SINGLE_CONTINUOUS_CONVERSION
      /* 4·α���ͨ��������ʵ�� */
      single_continuous_conversion_voltage();
#elif MODE == DIFFERENCE_CONVERSION
      /* 2·���ͨ�����ζ�ʵ�� */
      difference_conversion_voltage();
#elif MODE == DIFFERENCE_CONTINUOUS_CONVERSION
      /* 2·���ͨ��������ʵ�� */
      difference_continuous_conversion_voltage();
#elif MODE == ELECTRONIC_SCALE
      /* AD7192���ӳ�ʵ�� */
      electronic_scale_test();
#endif
  
  while (1)
  {
  }
}
/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (HSE)
  *            SYSCLK(Hz)                     = 72000000
  *            HCLK(Hz)                       = 72000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 2
  *            APB2 Prescaler                 = 1
  *            HSE Frequency(Hz)              = 8000000
  *            HSE PREDIV1                    = 2
  *            PLLMUL                         = 9
  *            Flash Latency(WS)              = 0
  * @param  None
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef clkinitstruct = {0};
  RCC_OscInitTypeDef oscinitstruct = {0};
  
  /* Enable HSE Oscillator and activate PLL with HSE as source */
  oscinitstruct.OscillatorType  = RCC_OSCILLATORTYPE_HSE;
  oscinitstruct.HSEState        = RCC_HSE_ON;
  oscinitstruct.HSEPredivValue  = RCC_HSE_PREDIV_DIV1;
  oscinitstruct.PLL.PLLState    = RCC_PLL_ON;
  oscinitstruct.PLL.PLLSource   = RCC_PLLSOURCE_HSE;
  oscinitstruct.PLL.PLLMUL      = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&oscinitstruct)!= HAL_OK)
  {
    /* Initialization Error */
    while(1); 
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
     clocks dividers */
  clkinitstruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  clkinitstruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  clkinitstruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  clkinitstruct.APB2CLKDivider = RCC_HCLK_DIV1;
  clkinitstruct.APB1CLKDivider = RCC_HCLK_DIV2;  
  if (HAL_RCC_ClockConfig(&clkinitstruct, FLASH_LATENCY_2)!= HAL_OK)
  {
    /* Initialization Error */
    while(1); 
  }
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
